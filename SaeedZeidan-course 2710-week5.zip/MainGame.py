from Live import load_game, welcome
print(welcome("Guy"))
load_game()